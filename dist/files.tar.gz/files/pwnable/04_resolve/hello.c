#include <stdio.h>

int main(void){
	printf("Hello, ");
	puts("World!");
	printf("waiwai");
}
