// 変数の宣言と初期値の代入
let name = 'John Doe'
let age = 42
const hobby = 'CTF'

// 変数の出力
console.log(name, age) // => John Doe 42
console.log('My hobby is ' + hobby) // => My hobby is CTF