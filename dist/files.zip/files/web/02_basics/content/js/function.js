// functionキーワードによる関数の定義
function add(a, b) {
  return a + b
}

// アロー関数と変数への代入
const sub = (a, b) => {
  return a - b
}

console.log(add(5, 3))
// => 8
console.log(sub(5, 3))
// => 2