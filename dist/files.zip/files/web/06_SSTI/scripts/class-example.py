#! python3

i = 1
print(i.__class__) # print(type(i))と同等


