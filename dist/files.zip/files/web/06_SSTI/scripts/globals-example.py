var=1
def func():
    pass

print(func.__globals__)
